﻿namespace QuanLyQuanCafe
{
    partial class fBillPaid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBoxBillPaid = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxBillPaid).BeginInit();
            SuspendLayout();
            // 
            // pictureBoxBillPaid
            // 
            pictureBoxBillPaid.Location = new Point(186, 12);
            pictureBoxBillPaid.Name = "pictureBoxBillPaid";
            pictureBoxBillPaid.Size = new Size(447, 475);
            pictureBoxBillPaid.TabIndex = 0;
            pictureBoxBillPaid.TabStop = false;
            // 
            // fBillPaid
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(859, 534);
            Controls.Add(pictureBoxBillPaid);
            Name = "fBillPaid";
            StartPosition = FormStartPosition.CenterParent;
            Text = "fBillPaid";
            ((System.ComponentModel.ISupportInitialize)pictureBoxBillPaid).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBoxBillPaid;
    }
}