﻿using QuanLyQuanCafe.DAO;
using QuanLyQuanCafe.DTO;
using System.Globalization;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.ListViewItem;

namespace QuanLyQuanCafe
{
    public partial class fTableManager : Form
    {
        private Account loginAccount;

        public Account LoginAccount
        {
            get { return loginAccount; }
            set { loginAccount = value; ChangeAccount(loginAccount.Type); }
        }

        public fTableManager(Account acc)
        {
            InitializeComponent();

            this.LoginAccount = acc;

            LoadTable();
            LoadCategory();
            LoadComboboxTable(comboBoxSwitchTable);
            LoadCategoryAndFood();
        }

        #region Method

        void ChangeAccount(int type)
        {
            adminToolStripMenuItem.Enabled = type == 1;
            thôngTinCáNhânToolStripMenuItem1.Text += " (" + LoginAccount.DisplayName + ") ";
        }

        void LoadCategory()
        {
            List<Category> listCategory = CategoryDAO.Instance.GetListCategory();
            comboBoxCategory.DataSource = listCategory;
            comboBoxCategory.DisplayMember = "Name";
        }

        void LoadFoodListByCategoryID(int id)
        {
            List<Food> listFood = FoodDAO.Instance.GetFoodByCategoryID(id);
            comboBoxFood.DataSource = listFood;
            comboBoxFood.DisplayMember = "Name";
        }


        void LoadTable()
        {
            flowLayoutPanelTable.Controls.Clear();

            List<Table> tableList = TableDAO.Instance.LoadTableList();

            foreach (Table item in tableList)
            {
                Button button = new Button() { Width = TableDAO.TableWidth, Height = TableDAO.TableHeight };
                button.Text = item.Name + Environment.NewLine + item.Status;
                button.Click += Button_Click;
                button.Tag = item;

                switch (item.Status)
                {
                    case "Trống":
                        button.BackColor = Color.Aqua;
                        break;
                    default:
                        button.BackColor = Color.LightPink;
                        break;
                }

                flowLayoutPanelTable.Controls.Add(button);
            }
        }


        void ShowBill(int id)
        {
            listViewBill.Items.Clear();
            List<QuanLyQuanCafe.DTO.Menu> listBillInfo = MenuDAO.Instance.GetListMenuByTable(id);
            float totalPrice = 0;
            foreach (QuanLyQuanCafe.DTO.Menu item in listBillInfo)
            {
                ListViewItem lsvItem = new ListViewItem(item.Foodname.ToString());
                lsvItem.SubItems.Add(item.Count.ToString());
                lsvItem.SubItems.Add(item.Price.ToString());
                lsvItem.SubItems.Add(item.TotalPice.ToString());
                totalPrice += item.TotalPice;
                listViewBill.Items.Add(lsvItem);
            }
            CultureInfo culture = new CultureInfo("vi-VN");

            //Thread.CurrentThread.CurrentCulture = culture;

            textBoxTotalPrice.Text = totalPrice.ToString("c", culture);

        }

        void LoadComboboxTable(ComboBox cb)
        {
            cb.DataSource = TableDAO.Instance.LoadTableList();
            cb.DisplayMember = "Name";
        }

        #endregion


        #region envents

        private void thêmMónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonAddFood_Click(this, new EventArgs());
        }

        private void thanhToánToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonCheckOut_Click(this, new EventArgs());
        }


        private void chuyểnBànToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonSwitchTable_Click(this, new EventArgs());
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát không?", "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Button_Click(object? sender, EventArgs e)
        {
            int tableID = ((sender as Button).Tag as Table).ID;
            listViewBill.Tag = (sender as Button).Tag;
            ShowBill(tableID);
        }

        private void fTableManager_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddFood_Click(object sender, EventArgs e)
        {
            Table table = listViewBill.Tag as Table;

            if (table == null)
            {
                MessageBox.Show("Hãy chọn bàn");
                return;
            }

            int idBill = BillDAO.Instance.GetUnCheckBillIDByTableID(table.ID);
            int foodID = (comboBoxFood.SelectedItem as Food).ID;
            int count = (int)numericUpDownFoodCount.Value;

            if (idBill == -1)
            {
                BillDAO.Instance.InsertBill(table.ID);
                BillInFoDAO.Instance.InsertBillInfo(BillDAO.Instance.GetMaxIDBill(), foodID, count);
            }
            else
            {
                BillInFoDAO.Instance.InsertBillInfo(idBill, foodID, count);
            }

            ShowBill(table.ID);

            LoadTable();

        }

        private void buttonDiscount_Click(object sender, EventArgs e)
        {

        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thôngTinCáNhânToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        void f_UpdateAccount(object sender, AccountEvent e)
        {
            thôngTinCáNhânToolStripMenuItem1.Text = "Thông tin tài khoản (" + e.Acc.DisplayName + ") ";
        }
        private void thôngTinCáNhânToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            fAccountProfile f = new fAccountProfile(LoginAccount);
            f.UpdateAccount += f_UpdateAccount;
            f.ShowDialog();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAdmin f = new fAdmin();
            f.loginAccount = LoginAccount;
            f.InsertFood += F_InsertFood;
            f.DeleteFood += F_DeleteFood;
            f.UpdateFood += F_UpdateFood;

            f.InsertTable += F_InsertTable;
            f.UpdateTable += F_UpdateTable;
            f.DeleteTable += F_DeleteTable;
            f.InsertCategory += F_InsertCategory;
            f.UpdateCategory += F_UpdateCategory;
            f.DeleteCategory += F_DeleteCategory;
            f.ShowDialog();
        }
        private void F_InsertCategory(object sender, EventArgs e)
        {
            LoadCategoryAndFood();
        }

        private void F_UpdateCategory(object sender, EventArgs e)
        {
            LoadCategoryAndFood();
        }

        private void F_DeleteCategory(object sender, EventArgs e)
        {
            LoadCategoryAndFood();
        }


        private void F_InsertTable(object sender, EventArgs e)
        {
            LoadTable();
        }

        private void F_UpdateTable(object sender, EventArgs e)
        {
            LoadTable();
        }

        private void F_DeleteTable(object sender, EventArgs e)
        {
            LoadTable();
        }
        private void F_InsertFood(object? sender, EventArgs e)
        {
            Category selectedCategory = comboBoxCategory.SelectedItem as Category;
            if (selectedCategory != null)
            {
                LoadFoodListByCategoryID(selectedCategory.ID);

                if (listViewBill.Tag != null)
                    ShowBill((listViewBill.Tag as Table).ID);
            }
        }


        private void F_UpdateFood(object? sender, EventArgs e)
        {
            Category selectedCategory = comboBoxCategory.SelectedItem as Category;
            if (selectedCategory != null)
            {
                LoadFoodListByCategoryID(selectedCategory.ID);

                if (listViewBill.Tag != null)
                    ShowBill((listViewBill.Tag as Table).ID);
            }
        }

        private void F_DeleteFood(object? sender, EventArgs e)
        {
            Category selectedCategory = comboBoxCategory.SelectedItem as Category;
            if (selectedCategory != null)
            {
                LoadFoodListByCategoryID(selectedCategory.ID);

                if (listViewBill.Tag != null)
                    ShowBill((listViewBill.Tag as Table).ID);
            }

            LoadTable();
        }
        private void LoadCategoryAndFood()
        {
            int selectedCategoryId = (comboBoxCategory.SelectedItem as Category)?.ID ?? -1;

            LoadCategory();

            if (selectedCategoryId != -1)
            {
                comboBoxCategory.SelectedItem = comboBoxCategory.Items
                    .Cast<Category>()
                    .FirstOrDefault(c => c.ID == selectedCategoryId);
            }
        }



        private void buttonCheckOut_Click(object sender, EventArgs e)
        {
            Table table = listViewBill.Tag as Table;

            int idBill = BillDAO.Instance.GetUnCheckBillIDByTableID(table.ID);
            int discount = (int)numericUpDownDiscount.Value;

            string cleanText = new string(textBoxTotalPrice.Text.Where(c => char.IsDigit(c) || c == '.').ToArray());
            double totalPrice = double.TryParse(cleanText, out double ketqua) ? ketqua : 0;

            double finalTotalPrice = totalPrice - (totalPrice / 100) * discount;


            if (idBill != -1)
            {
                DialogResult result = MessageBox.Show(string.Format("Bạn có chắc thanh toán hóa đơn cho bàn {0}\nTổng tiền - (Tổng tiền / 100) x Giảm giá\n=> {1}.000 - ({1}.000 / 100) x {2}% = {3}.000đ", table.Name, totalPrice, discount, finalTotalPrice), "Thông báo", MessageBoxButtons.OKCancel);

                if (result == DialogResult.OK)
                {
                    BillDAO.Instance.CheckOut(idBill, discount, (float)finalTotalPrice);
                    ShowBill(table.ID);
                    LoadTable();
                    ShowBillPaidPopup();
                }
            }
        }

        void ShowBillPaidPopup()
        {
            string imagePath = "C:\\Users\\khuon\\Downloads\\QR.png";
            fBillPaid popup = new fBillPaid(imagePath);
            popup.ShowDialog();
        }


        private void flowLayoutPanelTable_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBoxCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = 0;

            ComboBox cb = sender as ComboBox;

            if (cb.SelectedItem == null)
                return;

            Category selected = cb.SelectedItem as Category;
            id = selected.ID;

            LoadFoodListByCategoryID(id);
        }

        private void buttonSwitchTable_Click(object sender, EventArgs e)
        {
            int id1 = (listViewBill.Tag as Table).ID;

            int id2 = (comboBoxSwitchTable.SelectedItem as Table).ID;

            if (MessageBox.Show(string.Format("Bạn có thật sự muốn chuyển bàn {0} qua bàn {1} không ?", (listViewBill.Tag as Table).Name, (comboBoxSwitchTable.SelectedItem as Table).Name), "Thông báo", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            {
                TableDAO.Instance.SwitchTable(id1, id2);

                LoadTable();
            }
        }
        #endregion




        private void xemMónBánChạyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBestSellingFoods frm = new frmBestSellingFoods();
            frm.ShowDialog();
        }

        private void listViewBill_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
