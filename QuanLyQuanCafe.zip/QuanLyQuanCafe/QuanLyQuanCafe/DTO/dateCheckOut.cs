﻿namespace QuanLyQuanCafe.DTO
{
    public class dateCheckOut
    {
    }
}