﻿namespace QuanLyQuanCafe
{
    partial class fTableManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            adminToolStripMenuItem = new ToolStripMenuItem();
            thôngTinCáNhânToolStripMenuItem = new ToolStripMenuItem();
            thôngTinCáNhânToolStripMenuItem1 = new ToolStripMenuItem();
            đăngXuấtToolStripMenuItem = new ToolStripMenuItem();
            chứcNăngToolStripMenuItem = new ToolStripMenuItem();
            thêmMónToolStripMenuItem = new ToolStripMenuItem();
            thanhToánToolStripMenuItem = new ToolStripMenuItem();
            chuyểnBànToolStripMenuItem = new ToolStripMenuItem();
            thoátToolStripMenuItem = new ToolStripMenuItem();
            xemMónBánChạyToolStripMenuItem = new ToolStripMenuItem();
            panel2 = new Panel();
            listViewBill = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            panel3 = new Panel();
            textBoxTotalPrice = new TextBox();
            comboBoxSwitchTable = new ComboBox();
            buttonSwitchTable = new Button();
            buttonDiscount = new Button();
            numericUpDownDiscount = new NumericUpDown();
            buttonCheckOut = new Button();
            panel4 = new Panel();
            numericUpDownFoodCount = new NumericUpDown();
            comboBoxFood = new ComboBox();
            comboBoxCategory = new ComboBox();
            buttonAddFood = new Button();
            flowLayoutPanelTable = new FlowLayoutPanel();
            menuStrip1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownDiscount).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownFoodCount).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { adminToolStripMenuItem, thôngTinCáNhânToolStripMenuItem, chứcNăngToolStripMenuItem, xemMónBánChạyToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(10, 3, 0, 3);
            menuStrip1.Size = new Size(1791, 42);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // adminToolStripMenuItem
            // 
            adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            adminToolStripMenuItem.Size = new Size(104, 36);
            adminToolStripMenuItem.Text = "Admin";
            adminToolStripMenuItem.Click += adminToolStripMenuItem_Click;
            // 
            // thôngTinCáNhânToolStripMenuItem
            // 
            thôngTinCáNhânToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { thôngTinCáNhânToolStripMenuItem1, đăngXuấtToolStripMenuItem });
            thôngTinCáNhânToolStripMenuItem.Name = "thôngTinCáNhânToolStripMenuItem";
            thôngTinCáNhânToolStripMenuItem.Size = new Size(244, 36);
            thôngTinCáNhânToolStripMenuItem.Text = "Thông tin tài khoản";
            thôngTinCáNhânToolStripMenuItem.Click += thôngTinCáNhânToolStripMenuItem_Click;
            // 
            // thôngTinCáNhânToolStripMenuItem1
            // 
            thôngTinCáNhânToolStripMenuItem1.Name = "thôngTinCáNhânToolStripMenuItem1";
            thôngTinCáNhânToolStripMenuItem1.Size = new Size(342, 44);
            thôngTinCáNhânToolStripMenuItem1.Text = "Thông tin cá nhân";
            thôngTinCáNhânToolStripMenuItem1.Click += thôngTinCáNhânToolStripMenuItem1_Click;
            // 
            // đăngXuấtToolStripMenuItem
            // 
            đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            đăngXuấtToolStripMenuItem.Size = new Size(342, 44);
            đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            đăngXuấtToolStripMenuItem.Click += đăngXuấtToolStripMenuItem_Click;
            // 
            // chứcNăngToolStripMenuItem
            // 
            chứcNăngToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { thêmMónToolStripMenuItem, thanhToánToolStripMenuItem, chuyểnBànToolStripMenuItem, thoátToolStripMenuItem });
            chứcNăngToolStripMenuItem.Name = "chứcNăngToolStripMenuItem";
            chứcNăngToolStripMenuItem.Size = new Size(149, 36);
            chứcNăngToolStripMenuItem.Text = "Chức năng";
            // 
            // thêmMónToolStripMenuItem
            // 
            thêmMónToolStripMenuItem.Name = "thêmMónToolStripMenuItem";
            thêmMónToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.A;
            thêmMónToolStripMenuItem.Size = new Size(356, 44);
            thêmMónToolStripMenuItem.Text = "Thêm món";
            thêmMónToolStripMenuItem.Click += thêmMónToolStripMenuItem_Click;
            // 
            // thanhToánToolStripMenuItem
            // 
            thanhToánToolStripMenuItem.Name = "thanhToánToolStripMenuItem";
            thanhToánToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.P;
            thanhToánToolStripMenuItem.Size = new Size(356, 44);
            thanhToánToolStripMenuItem.Text = "Thanh toán";
            thanhToánToolStripMenuItem.Click += thanhToánToolStripMenuItem_Click;
            // 
            // chuyểnBànToolStripMenuItem
            // 
            chuyểnBànToolStripMenuItem.Name = "chuyểnBànToolStripMenuItem";
            chuyểnBànToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.S;
            chuyểnBànToolStripMenuItem.Size = new Size(356, 44);
            chuyểnBànToolStripMenuItem.Text = "Chuyển bàn";
            chuyểnBànToolStripMenuItem.Click += chuyểnBànToolStripMenuItem_Click;
            // 
            // thoátToolStripMenuItem
            // 
            thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            thoátToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.E;
            thoátToolStripMenuItem.Size = new Size(356, 44);
            thoátToolStripMenuItem.Text = "Thoát";
            thoátToolStripMenuItem.Click += thoátToolStripMenuItem_Click;
            // 
            // xemMónBánChạyToolStripMenuItem
            // 
            xemMónBánChạyToolStripMenuItem.Name = "xemMónBánChạyToolStripMenuItem";
            xemMónBánChạyToolStripMenuItem.Size = new Size(241, 36);
            xemMónBánChạyToolStripMenuItem.Text = "Xem món bán chạy";
            xemMónBánChạyToolStripMenuItem.Click += xemMónBánChạyToolStripMenuItem_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(listViewBill);
            panel2.Location = new Point(939, 182);
            panel2.Margin = new Padding(5);
            panel2.Name = "panel2";
            panel2.Size = new Size(832, 666);
            panel2.TabIndex = 2;
            // 
            // listViewBill
            // 
            listViewBill.BackColor = SystemColors.Menu;
            listViewBill.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4 });
            listViewBill.GridLines = true;
            listViewBill.Location = new Point(5, 5);
            listViewBill.Margin = new Padding(5);
            listViewBill.Name = "listViewBill";
            listViewBill.Size = new Size(820, 654);
            listViewBill.TabIndex = 0;
            listViewBill.UseCompatibleStateImageBehavior = false;
            listViewBill.View = View.Details;
            listViewBill.SelectedIndexChanged += listViewBill_SelectedIndexChanged;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Tên món";
            columnHeader1.Width = 150;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Số lượng";
            columnHeader2.Width = 150;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Đơn giá";
            columnHeader3.Width = 125;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Thành tiền";
            columnHeader4.Width = 145;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ActiveCaption;
            panel3.Controls.Add(textBoxTotalPrice);
            panel3.Controls.Add(comboBoxSwitchTable);
            panel3.Controls.Add(buttonSwitchTable);
            panel3.Controls.Add(buttonDiscount);
            panel3.Controls.Add(numericUpDownDiscount);
            panel3.Controls.Add(buttonCheckOut);
            panel3.Location = new Point(939, 853);
            panel3.Margin = new Padding(5);
            panel3.Name = "panel3";
            panel3.Size = new Size(832, 114);
            panel3.TabIndex = 3;
            // 
            // textBoxTotalPrice
            // 
            textBoxTotalPrice.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            textBoxTotalPrice.ForeColor = Color.OrangeRed;
            textBoxTotalPrice.Location = new Point(385, 35);
            textBoxTotalPrice.Margin = new Padding(5);
            textBoxTotalPrice.Name = "textBoxTotalPrice";
            textBoxTotalPrice.ReadOnly = true;
            textBoxTotalPrice.Size = new Size(279, 41);
            textBoxTotalPrice.TabIndex = 7;
            textBoxTotalPrice.Text = "0";
            textBoxTotalPrice.TextAlign = HorizontalAlignment.Right;
            // 
            // comboBoxSwitchTable
            // 
            comboBoxSwitchTable.FormattingEnabled = true;
            comboBoxSwitchTable.Location = new Point(5, 61);
            comboBoxSwitchTable.Margin = new Padding(5);
            comboBoxSwitchTable.Name = "comboBoxSwitchTable";
            comboBoxSwitchTable.Size = new Size(178, 40);
            comboBoxSwitchTable.TabIndex = 4;
            // 
            // buttonSwitchTable
            // 
            buttonSwitchTable.Location = new Point(5, 5);
            buttonSwitchTable.Margin = new Padding(5);
            buttonSwitchTable.Name = "buttonSwitchTable";
            buttonSwitchTable.Size = new Size(180, 56);
            buttonSwitchTable.TabIndex = 6;
            buttonSwitchTable.Text = "Chuyển bàn";
            buttonSwitchTable.UseVisualStyleBackColor = true;
            buttonSwitchTable.Click += buttonSwitchTable_Click;
            // 
            // buttonDiscount
            // 
            buttonDiscount.Location = new Point(195, 5);
            buttonDiscount.Margin = new Padding(5);
            buttonDiscount.Name = "buttonDiscount";
            buttonDiscount.Size = new Size(180, 56);
            buttonDiscount.TabIndex = 5;
            buttonDiscount.Text = "Giảm giá (%)\r\n";
            buttonDiscount.UseVisualStyleBackColor = true;
            buttonDiscount.Click += buttonDiscount_Click;
            // 
            // numericUpDownDiscount
            // 
            numericUpDownDiscount.Location = new Point(195, 61);
            numericUpDownDiscount.Margin = new Padding(5);
            numericUpDownDiscount.Name = "numericUpDownDiscount";
            numericUpDownDiscount.Size = new Size(180, 39);
            numericUpDownDiscount.TabIndex = 4;
            numericUpDownDiscount.TextAlign = HorizontalAlignment.Center;
            numericUpDownDiscount.UseWaitCursor = true;
            // 
            // buttonCheckOut
            // 
            buttonCheckOut.Location = new Point(676, 6);
            buttonCheckOut.Margin = new Padding(5);
            buttonCheckOut.Name = "buttonCheckOut";
            buttonCheckOut.Size = new Size(151, 99);
            buttonCheckOut.TabIndex = 4;
            buttonCheckOut.Text = "Thanh toán";
            buttonCheckOut.UseVisualStyleBackColor = true;
            buttonCheckOut.Click += buttonCheckOut_Click;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ActiveCaption;
            panel4.Controls.Add(numericUpDownFoodCount);
            panel4.Controls.Add(comboBoxFood);
            panel4.Controls.Add(comboBoxCategory);
            panel4.Controls.Add(buttonAddFood);
            panel4.Location = new Point(939, 69);
            panel4.Margin = new Padding(5);
            panel4.Name = "panel4";
            panel4.Size = new Size(832, 112);
            panel4.TabIndex = 4;
            // 
            // numericUpDownFoodCount
            // 
            numericUpDownFoodCount.Location = new Point(728, 37);
            numericUpDownFoodCount.Margin = new Padding(5);
            numericUpDownFoodCount.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
            numericUpDownFoodCount.Name = "numericUpDownFoodCount";
            numericUpDownFoodCount.Size = new Size(99, 39);
            numericUpDownFoodCount.TabIndex = 3;
            numericUpDownFoodCount.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // comboBoxFood
            // 
            comboBoxFood.FormattingEnabled = true;
            comboBoxFood.Location = new Point(5, 59);
            comboBoxFood.Margin = new Padding(5);
            comboBoxFood.Name = "comboBoxFood";
            comboBoxFood.Size = new Size(461, 40);
            comboBoxFood.TabIndex = 1;
            // 
            // comboBoxCategory
            // 
            comboBoxCategory.FormattingEnabled = true;
            comboBoxCategory.Location = new Point(5, 5);
            comboBoxCategory.Margin = new Padding(5);
            comboBoxCategory.Name = "comboBoxCategory";
            comboBoxCategory.Size = new Size(461, 40);
            comboBoxCategory.TabIndex = 0;
            comboBoxCategory.SelectedIndexChanged += comboBoxCategory_SelectedIndexChanged;
            // 
            // buttonAddFood
            // 
            buttonAddFood.Location = new Point(522, 5);
            buttonAddFood.Margin = new Padding(5);
            buttonAddFood.Name = "buttonAddFood";
            buttonAddFood.Size = new Size(172, 104);
            buttonAddFood.TabIndex = 2;
            buttonAddFood.Text = "Thêm món";
            buttonAddFood.UseVisualStyleBackColor = true;
            buttonAddFood.Click += buttonAddFood_Click;
            // 
            // flowLayoutPanelTable
            // 
            flowLayoutPanelTable.AutoScroll = true;
            flowLayoutPanelTable.BackColor = SystemColors.ActiveCaption;
            flowLayoutPanelTable.ForeColor = SystemColors.ControlText;
            flowLayoutPanelTable.Location = new Point(20, 69);
            flowLayoutPanelTable.Margin = new Padding(5);
            flowLayoutPanelTable.Name = "flowLayoutPanelTable";
            flowLayoutPanelTable.Size = new Size(910, 898);
            flowLayoutPanelTable.TabIndex = 5;
            flowLayoutPanelTable.Paint += flowLayoutPanelTable_Paint;
            // 
            // fTableManager
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1791, 986);
            Controls.Add(flowLayoutPanelTable);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(menuStrip1);
            Margin = new Padding(5);
            Name = "fTableManager";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Phần mềm quản lý quán cafe";
            Load += fTableManager_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownDiscount).EndInit();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)numericUpDownFoodCount).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem adminToolStripMenuItem;
        private ToolStripMenuItem thôngTinCáNhânToolStripMenuItem;
        private ToolStripMenuItem thôngTinCáNhânToolStripMenuItem1;
        private ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private Panel panel2;
        private ListView listViewBill;
        private Panel panel3;
        private Panel panel4;
        private ComboBox comboBoxCategory;
        private NumericUpDown numericUpDownFoodCount;
        private Button buttonAddFood;
        private ComboBox comboBoxFood;
        private FlowLayoutPanel flowLayoutPanelTable;
        private Button buttonCheckOut;
        private Button buttonDiscount;
        private NumericUpDown numericUpDownDiscount;
        private Button buttonSwitchTable;
        private ComboBox comboBoxSwitchTable;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private TextBox textBoxTotalPrice;
        private ToolStripMenuItem chứcNăngToolStripMenuItem;
        private ToolStripMenuItem thêmMónToolStripMenuItem;
        private ToolStripMenuItem thanhToánToolStripMenuItem;
        private ToolStripMenuItem chuyểnBànToolStripMenuItem;
        private ToolStripMenuItem thoátToolStripMenuItem;
        private ToolStripMenuItem xemMónBánChạyToolStripMenuItem;
    }
}