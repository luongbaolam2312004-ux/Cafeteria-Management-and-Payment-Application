﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyQuanCafe
{
    public partial class fBillPaid : Form
    {
        public fBillPaid()
        {
            InitializeComponent();
        }

        public fBillPaid(string imagePath) : this()
        {
            pictureBoxBillPaid.Image = Image.FromFile(imagePath);
        }
    }
}
