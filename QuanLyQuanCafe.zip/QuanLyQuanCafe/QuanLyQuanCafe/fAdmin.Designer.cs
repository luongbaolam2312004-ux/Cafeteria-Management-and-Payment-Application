﻿namespace QuanLyQuanCafe
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabPage1 = new TabPage();
            tabPageCategory = new TabPage();
            panel13 = new Panel();
            buttonShowCategory = new Button();
            buttonEditCategory = new Button();
            buttonDeleteCategory = new Button();
            buttonAddCategory = new Button();
            panel16 = new Panel();
            panel22 = new Panel();
            textBoxNameCategory = new TextBox();
            label14 = new Label();
            panel30 = new Panel();
            textBoxCategoryID = new TextBox();
            label15 = new Label();
            panel31 = new Panel();
            dataGridViewCategory = new DataGridView();
            tabPageTable = new TabPage();
            panel11 = new Panel();
            buttonShowTable = new Button();
            buttonEditTable = new Button();
            buttonDeleteTable = new Button();
            buttonAddTable = new Button();
            panel14 = new Panel();
            panel21 = new Panel();
            comboBoxTableStatus = new ComboBox();
            label9 = new Label();
            panel15 = new Panel();
            textBoxTableName = new TextBox();
            label5 = new Label();
            panel19 = new Panel();
            textBoxTableID = new TextBox();
            label6 = new Label();
            panel20 = new Panel();
            dataGridViewTable = new DataGridView();
            tabPageFood = new TabPage();
            panel6 = new Panel();
            textBoxSearchFoodName = new TextBox();
            buttonSearchFood = new Button();
            panel5 = new Panel();
            buttonShowFood = new Button();
            buttonEditFood = new Button();
            buttonDeleteFood = new Button();
            buttonAddFood = new Button();
            panel4 = new Panel();
            panel10 = new Panel();
            numericUpDownFoodPrice = new NumericUpDown();
            label4 = new Label();
            panel9 = new Panel();
            comboBoxFoodCategory = new ComboBox();
            label3 = new Label();
            panel8 = new Panel();
            textBoxFoodName = new TextBox();
            label2 = new Label();
            panel7 = new Panel();
            textboxFoodID = new TextBox();
            label1 = new Label();
            panel3 = new Panel();
            dataGridViewFood = new DataGridView();
            tabPageBill = new TabPage();
            panel2 = new Panel();
            buttonViewBill = new Button();
            dateTimePickerToDate = new DateTimePicker();
            dateTimePickerFromDate = new DateTimePicker();
            panel1 = new Panel();
            textBoxPageBill = new TextBox();
            buttonNextBillPage = new Button();
            buttonLastBillPage = new Button();
            buttonPreviousBillPage = new Button();
            buttonFirst = new Button();
            dataGridViewBill = new DataGridView();
            tabControlAdmin = new TabControl();
            tabPageCategory.SuspendLayout();
            panel13.SuspendLayout();
            panel16.SuspendLayout();
            panel22.SuspendLayout();
            panel30.SuspendLayout();
            panel31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCategory).BeginInit();
            tabPageTable.SuspendLayout();
            panel11.SuspendLayout();
            panel14.SuspendLayout();
            panel21.SuspendLayout();
            panel15.SuspendLayout();
            panel19.SuspendLayout();
            panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTable).BeginInit();
            tabPageFood.SuspendLayout();
            panel6.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownFoodPrice).BeginInit();
            panel9.SuspendLayout();
            panel8.SuspendLayout();
            panel7.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewFood).BeginInit();
            tabPageBill.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBill).BeginInit();
            tabControlAdmin.SuspendLayout();
            SuspendLayout();
            // 
           
            // 
            // tabPageCategory
            // 
            tabPageCategory.Controls.Add(panel13);
            tabPageCategory.Controls.Add(panel16);
            tabPageCategory.Controls.Add(panel31);
            tabPageCategory.Location = new Point(8, 46);
            tabPageCategory.Margin = new Padding(5);
            tabPageCategory.Name = "tabPageCategory";
            tabPageCategory.Padding = new Padding(5);
            tabPageCategory.Size = new Size(1486, 895);
            tabPageCategory.TabIndex = 5;
            tabPageCategory.Text = "Danh mục";
            tabPageCategory.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            panel13.Controls.Add(buttonShowCategory);
            panel13.Controls.Add(buttonEditCategory);
            panel13.Controls.Add(buttonDeleteCategory);
            panel13.Controls.Add(buttonAddCategory);
            panel13.Location = new Point(8, 8);
            panel13.Margin = new Padding(5);
            panel13.Name = "panel13";
            panel13.Size = new Size(798, 147);
            panel13.TabIndex = 6;
            // 
            // buttonShowCategory
            // 
            buttonShowCategory.Location = new Point(0, 0);
            buttonShowCategory.Name = "buttonShowCategory";
            buttonShowCategory.Size = new Size(75, 23);
            buttonShowCategory.TabIndex = 0;
            // 
            // buttonEditCategory
            // 
            buttonEditCategory.Location = new Point(375, 5);
            buttonEditCategory.Margin = new Padding(5);
            buttonEditCategory.Name = "buttonEditCategory";
            buttonEditCategory.Size = new Size(174, 138);
            buttonEditCategory.TabIndex = 2;
            buttonEditCategory.Text = "Sửa";
            buttonEditCategory.UseVisualStyleBackColor = true;
            buttonEditCategory.Click += buttonEditCategory_Click;
            // 
            // buttonDeleteCategory
            // 
            buttonDeleteCategory.Location = new Point(192, 5);
            buttonDeleteCategory.Margin = new Padding(5);
            buttonDeleteCategory.Name = "buttonDeleteCategory";
            buttonDeleteCategory.Size = new Size(174, 138);
            buttonDeleteCategory.TabIndex = 1;
            buttonDeleteCategory.Text = "Xóa";
            buttonDeleteCategory.UseVisualStyleBackColor = true;
            buttonDeleteCategory.Click += buttonDeleteCategory_Click;
            // 
            // buttonAddCategory
            // 
            buttonAddCategory.Location = new Point(8, 5);
            buttonAddCategory.Margin = new Padding(5);
            buttonAddCategory.Name = "buttonAddCategory";
            buttonAddCategory.Size = new Size(174, 138);
            buttonAddCategory.TabIndex = 0;
            buttonAddCategory.Text = "Thêm";
            buttonAddCategory.UseVisualStyleBackColor = true;
            buttonAddCategory.Click += buttonAddCategory_Click;
            // 
            // panel16
            // 
            panel16.Controls.Add(panel22);
            panel16.Controls.Add(panel30);
            panel16.Location = new Point(881, 165);
            panel16.Margin = new Padding(5);
            panel16.Name = "panel16";
            panel16.Size = new Size(601, 725);
            panel16.TabIndex = 5;
            // 
            // panel22
            // 
            panel22.Controls.Add(textBoxNameCategory);
            panel22.Controls.Add(label14);
            panel22.Location = new Point(5, 112);
            panel22.Margin = new Padding(5);
            panel22.Name = "panel22";
            panel22.Size = new Size(596, 98);
            panel22.TabIndex = 2;
            // 
            // textBoxNameCategory
            // 
            textBoxNameCategory.Location = new Point(271, 29);
            textBoxNameCategory.Margin = new Padding(5);
            textBoxNameCategory.Name = "textBoxNameCategory";
            textBoxNameCategory.Size = new Size(318, 39);
            textBoxNameCategory.TabIndex = 1;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(5, 29);
            label14.Margin = new Padding(5, 0, 5, 0);
            label14.Name = "label14";
            label14.Size = new Size(251, 37);
            label14.TabIndex = 0;
            label14.Text = "Tên danh mục :";
            // 
            // panel30
            // 
            panel30.Controls.Add(textBoxCategoryID);
            panel30.Controls.Add(label15);
            panel30.Location = new Point(5, 5);
            panel30.Margin = new Padding(5);
            panel30.Name = "panel30";
            panel30.Size = new Size(596, 98);
            panel30.TabIndex = 3;
            // 
            // textBoxCategoryID
            // 
            textBoxCategoryID.Location = new Point(271, 29);
            textBoxCategoryID.Margin = new Padding(5);
            textBoxCategoryID.Name = "textBoxCategoryID";
            textBoxCategoryID.ReadOnly = true;
            textBoxCategoryID.Size = new Size(318, 39);
            textBoxCategoryID.TabIndex = 1;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.Location = new Point(5, 29);
            label15.Margin = new Padding(5, 0, 5, 0);
            label15.Name = "label15";
            label15.Size = new Size(67, 37);
            label15.TabIndex = 0;
            label15.Text = "ID :";
            // 
            // panel31
            // 
            panel31.Controls.Add(dataGridViewCategory);
            panel31.Location = new Point(8, 165);
            panel31.Margin = new Padding(5);
            panel31.Name = "panel31";
            panel31.Size = new Size(863, 725);
            panel31.TabIndex = 4;
            // 
            // dataGridViewCategory
            // 
            dataGridViewCategory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCategory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCategory.Location = new Point(8, 5);
            dataGridViewCategory.Margin = new Padding(5);
            dataGridViewCategory.Name = "dataGridViewCategory";
            dataGridViewCategory.RowHeadersWidth = 51;
            dataGridViewCategory.Size = new Size(850, 720);
            dataGridViewCategory.TabIndex = 0;
            // 
            // tabPageTable
            // 
            tabPageTable.Controls.Add(panel11);
            tabPageTable.Controls.Add(panel14);
            tabPageTable.Controls.Add(panel20);
            tabPageTable.Location = new Point(8, 46);
            tabPageTable.Margin = new Padding(5);
            tabPageTable.Name = "tabPageTable";
            tabPageTable.Padding = new Padding(5);
            tabPageTable.Size = new Size(1486, 895);
            tabPageTable.TabIndex = 3;
            tabPageTable.Text = "Bàn ăn";
            tabPageTable.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            panel11.Controls.Add(buttonShowTable);
            panel11.Controls.Add(buttonEditTable);
            panel11.Controls.Add(buttonDeleteTable);
            panel11.Controls.Add(buttonAddTable);
            panel11.Location = new Point(8, 8);
            panel11.Margin = new Padding(5);
            panel11.Name = "panel11";
            panel11.Size = new Size(798, 147);
            panel11.TabIndex = 9;
            // 
            // buttonShowTable
            // 
            buttonShowTable.Location = new Point(0, 0);
            buttonShowTable.Name = "buttonShowTable";
            buttonShowTable.Size = new Size(75, 23);
            buttonShowTable.TabIndex = 0;
            // 
            // buttonEditTable
            // 
            buttonEditTable.Location = new Point(375, 5);
            buttonEditTable.Margin = new Padding(5);
            buttonEditTable.Name = "buttonEditTable";
            buttonEditTable.Size = new Size(174, 138);
            buttonEditTable.TabIndex = 2;
            buttonEditTable.Text = "Sửa";
            buttonEditTable.UseVisualStyleBackColor = true;
            buttonEditTable.Click += buttonEditTable_Click;
            // 
            // buttonDeleteTable
            // 
            buttonDeleteTable.Location = new Point(192, 5);
            buttonDeleteTable.Margin = new Padding(5);
            buttonDeleteTable.Name = "buttonDeleteTable";
            buttonDeleteTable.Size = new Size(174, 138);
            buttonDeleteTable.TabIndex = 1;
            buttonDeleteTable.Text = "Xóa";
            buttonDeleteTable.UseVisualStyleBackColor = true;
            buttonDeleteTable.Click += buttonDeleteTable_Click;
            // 
            // buttonAddTable
            // 
            buttonAddTable.Location = new Point(8, 5);
            buttonAddTable.Margin = new Padding(5);
            buttonAddTable.Name = "buttonAddTable";
            buttonAddTable.Size = new Size(174, 138);
            buttonAddTable.TabIndex = 0;
            buttonAddTable.Text = "Thêm";
            buttonAddTable.UseVisualStyleBackColor = true;
            buttonAddTable.Click += buttonAddTable_Click;
            // 
            // panel14
            // 
            panel14.Controls.Add(panel21);
            panel14.Controls.Add(panel15);
            panel14.Controls.Add(panel19);
            panel14.Location = new Point(816, 165);
            panel14.Margin = new Padding(5);
            panel14.Name = "panel14";
            panel14.Size = new Size(666, 725);
            panel14.TabIndex = 8;
            // 
            // panel21
            // 
            panel21.Controls.Add(comboBoxTableStatus);
            panel21.Controls.Add(label9);
            panel21.Location = new Point(5, 219);
            panel21.Margin = new Padding(5);
            panel21.Name = "panel21";
            panel21.Size = new Size(661, 98);
            panel21.TabIndex = 3;
            // 
            // comboBoxTableStatus
            // 
            comboBoxTableStatus.FormattingEnabled = true;
            comboBoxTableStatus.Location = new Point(208, 29);
            comboBoxTableStatus.Margin = new Padding(5);
            comboBoxTableStatus.Name = "comboBoxTableStatus";
            comboBoxTableStatus.Size = new Size(441, 40);
            comboBoxTableStatus.TabIndex = 1;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(5, 29);
            label9.Margin = new Padding(5, 0, 5, 0);
            label9.Name = "label9";
            label9.Size = new Size(190, 37);
            label9.TabIndex = 0;
            label9.Text = "Trạng thái :";
            // 
            // panel15
            // 
            panel15.Controls.Add(textBoxTableName);
            panel15.Controls.Add(label5);
            panel15.Location = new Point(5, 112);
            panel15.Margin = new Padding(5);
            panel15.Name = "panel15";
            panel15.Size = new Size(661, 98);
            panel15.TabIndex = 2;
            // 
            // textBoxTableName
            // 
            textBoxTableName.Location = new Point(208, 29);
            textBoxTableName.Margin = new Padding(5);
            textBoxTableName.Name = "textBoxTableName";
            textBoxTableName.Size = new Size(441, 39);
            textBoxTableName.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(5, 29);
            label5.Margin = new Padding(5, 0, 5, 0);
            label5.Name = "label5";
            label5.Size = new Size(158, 37);
            label5.TabIndex = 0;
            label5.Text = "Tên bàn :";
            // 
            // panel19
            // 
            panel19.Controls.Add(textBoxTableID);
            panel19.Controls.Add(label6);
            panel19.Location = new Point(5, 5);
            panel19.Margin = new Padding(5);
            panel19.Name = "panel19";
            panel19.Size = new Size(656, 98);
            panel19.TabIndex = 3;
            // 
            // textBoxTableID
            // 
            textBoxTableID.Location = new Point(208, 29);
            textBoxTableID.Margin = new Padding(5);
            textBoxTableID.Name = "textBoxTableID";
            textBoxTableID.ReadOnly = true;
            textBoxTableID.Size = new Size(441, 39);
            textBoxTableID.TabIndex = 1;
            textBoxTableID.TextChanged += textBox3_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(5, 29);
            label6.Margin = new Padding(5, 0, 5, 0);
            label6.Name = "label6";
            label6.Size = new Size(67, 37);
            label6.TabIndex = 0;
            label6.Text = "ID :";
            // 
            // panel20
            // 
            panel20.Controls.Add(dataGridViewTable);
            panel20.Location = new Point(8, 165);
            panel20.Margin = new Padding(5);
            panel20.Name = "panel20";
            panel20.Size = new Size(798, 725);
            panel20.TabIndex = 7;
            // 
            // dataGridViewTable
            // 
            dataGridViewTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewTable.Location = new Point(8, 5);
            dataGridViewTable.Margin = new Padding(5);
            dataGridViewTable.Name = "dataGridViewTable";
            dataGridViewTable.RowHeadersWidth = 51;
            dataGridViewTable.Size = new Size(785, 720);
            dataGridViewTable.TabIndex = 0;
            // 
            // tabPageFood
            // 
            tabPageFood.Controls.Add(panel6);
            tabPageFood.Controls.Add(panel5);
            tabPageFood.Controls.Add(panel4);
            tabPageFood.Controls.Add(panel3);
            tabPageFood.Location = new Point(8, 46);
            tabPageFood.Margin = new Padding(5);
            tabPageFood.Name = "tabPageFood";
            tabPageFood.Padding = new Padding(5);
            tabPageFood.Size = new Size(1486, 895);
            tabPageFood.TabIndex = 1;
            tabPageFood.Text = "Thức ăn";
            tabPageFood.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            panel6.Controls.Add(textBoxSearchFoodName);
            panel6.Controls.Add(buttonSearchFood);
            panel6.Location = new Point(812, 10);
            panel6.Margin = new Padding(5);
            panel6.Name = "panel6";
            panel6.Size = new Size(666, 147);
            panel6.TabIndex = 3;
            // 
            // textBoxSearchFoodName
            // 
            textBoxSearchFoodName.Location = new Point(5, 53);
            textBoxSearchFoodName.Margin = new Padding(5);
            textBoxSearchFoodName.Name = "textBoxSearchFoodName";
            textBoxSearchFoodName.Size = new Size(470, 39);
            textBoxSearchFoodName.TabIndex = 2;
            // 
            // buttonSearchFood
            // 
            buttonSearchFood.Location = new Point(488, 5);
            buttonSearchFood.Margin = new Padding(5);
            buttonSearchFood.Name = "buttonSearchFood";
            buttonSearchFood.Size = new Size(174, 138);
            buttonSearchFood.TabIndex = 1;
            buttonSearchFood.Text = "Tìm";
            buttonSearchFood.UseVisualStyleBackColor = true;
            buttonSearchFood.Click += buttonSearchFood_Click;
            // 
            // panel5
            // 
            panel5.Controls.Add(buttonShowFood);
            panel5.Controls.Add(buttonEditFood);
            panel5.Controls.Add(buttonDeleteFood);
            panel5.Controls.Add(buttonAddFood);
            panel5.Location = new Point(5, 10);
            panel5.Margin = new Padding(5);
            panel5.Name = "panel5";
            panel5.Size = new Size(798, 147);
            panel5.TabIndex = 2;
            // 
            // buttonShowFood
            // 
            buttonShowFood.Location = new Point(0, 0);
            buttonShowFood.Name = "buttonShowFood";
            buttonShowFood.Size = new Size(75, 23);
            buttonShowFood.TabIndex = 0;
            // 
            // buttonEditFood
            // 
            buttonEditFood.Location = new Point(375, 5);
            buttonEditFood.Margin = new Padding(5);
            buttonEditFood.Name = "buttonEditFood";
            buttonEditFood.Size = new Size(174, 138);
            buttonEditFood.TabIndex = 2;
            buttonEditFood.Text = "Sửa";
            buttonEditFood.UseVisualStyleBackColor = true;
            buttonEditFood.Click += buttonEditFood_Click;
            // 
            // buttonDeleteFood
            // 
            buttonDeleteFood.Location = new Point(192, 5);
            buttonDeleteFood.Margin = new Padding(5);
            buttonDeleteFood.Name = "buttonDeleteFood";
            buttonDeleteFood.Size = new Size(174, 138);
            buttonDeleteFood.TabIndex = 1;
            buttonDeleteFood.Text = "Xóa";
            buttonDeleteFood.UseVisualStyleBackColor = true;
            buttonDeleteFood.Click += buttonDeleteFood_Click;
            // 
            // buttonAddFood
            // 
            buttonAddFood.Location = new Point(8, 5);
            buttonAddFood.Margin = new Padding(5);
            buttonAddFood.Name = "buttonAddFood";
            buttonAddFood.Size = new Size(174, 138);
            buttonAddFood.TabIndex = 0;
            buttonAddFood.Text = "Thêm";
            buttonAddFood.UseVisualStyleBackColor = true;
            buttonAddFood.Click += buttonAddFood_Click;
            // 
            // panel4
            // 
            panel4.Controls.Add(panel10);
            panel4.Controls.Add(panel9);
            panel4.Controls.Add(panel8);
            panel4.Controls.Add(panel7);
            panel4.Location = new Point(878, 166);
            panel4.Margin = new Padding(5);
            panel4.Name = "panel4";
            panel4.Size = new Size(601, 725);
            panel4.TabIndex = 1;
            // 
            // panel10
            // 
            panel10.Controls.Add(numericUpDownFoodPrice);
            panel10.Controls.Add(label4);
            panel10.Location = new Point(5, 326);
            panel10.Margin = new Padding(5);
            panel10.Name = "panel10";
            panel10.Size = new Size(596, 98);
            panel10.TabIndex = 2;
            // 
            // numericUpDownFoodPrice
            // 
            numericUpDownFoodPrice.Location = new Point(206, 24);
            numericUpDownFoodPrice.Margin = new Padding(5);
            numericUpDownFoodPrice.Maximum = new decimal(new int[] { 1410065408, 2, 0, 0 });
            numericUpDownFoodPrice.Name = "numericUpDownFoodPrice";
            numericUpDownFoodPrice.Size = new Size(385, 39);
            numericUpDownFoodPrice.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(5, 29);
            label4.Margin = new Padding(5, 0, 5, 0);
            label4.Name = "label4";
            label4.Size = new Size(89, 37);
            label4.TabIndex = 0;
            label4.Text = "Giá :";
            // 
            // panel9
            // 
            panel9.Controls.Add(comboBoxFoodCategory);
            panel9.Controls.Add(label3);
            panel9.Location = new Point(5, 219);
            panel9.Margin = new Padding(5);
            panel9.Name = "panel9";
            panel9.Size = new Size(596, 98);
            panel9.TabIndex = 2;
            // 
            // comboBoxFoodCategory
            // 
            comboBoxFoodCategory.FormattingEnabled = true;
            comboBoxFoodCategory.Location = new Point(206, 29);
            comboBoxFoodCategory.Margin = new Padding(5);
            comboBoxFoodCategory.Name = "comboBoxFoodCategory";
            comboBoxFoodCategory.Size = new Size(383, 40);
            comboBoxFoodCategory.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(5, 29);
            label3.Margin = new Padding(5, 0, 5, 0);
            label3.Name = "label3";
            label3.Size = new Size(189, 37);
            label3.TabIndex = 0;
            label3.Text = "Danh mục :";
            // 
            // panel8
            // 
            panel8.Controls.Add(textBoxFoodName);
            panel8.Controls.Add(label2);
            panel8.Location = new Point(5, 112);
            panel8.Margin = new Padding(5);
            panel8.Name = "panel8";
            panel8.Size = new Size(596, 98);
            panel8.TabIndex = 2;
            // 
            // textBoxFoodName
            // 
            textBoxFoodName.Location = new Point(206, 29);
            textBoxFoodName.Margin = new Padding(5);
            textBoxFoodName.Name = "textBoxFoodName";
            textBoxFoodName.Size = new Size(383, 39);
            textBoxFoodName.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(5, 29);
            label2.Margin = new Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new Size(168, 37);
            label2.TabIndex = 0;
            label2.Text = "Tên món :";
            // 
            // panel7
            // 
            panel7.Controls.Add(textboxFoodID);
            panel7.Controls.Add(label1);
            panel7.Location = new Point(5, 5);
            panel7.Margin = new Padding(5);
            panel7.Name = "panel7";
            panel7.Size = new Size(596, 98);
            panel7.TabIndex = 3;
            // 
            // textboxFoodID
            // 
            textboxFoodID.Location = new Point(206, 29);
            textboxFoodID.Margin = new Padding(5);
            textboxFoodID.Name = "textboxFoodID";
            textboxFoodID.ReadOnly = true;
            textboxFoodID.Size = new Size(383, 39);
            textboxFoodID.TabIndex = 1;
            textboxFoodID.TextChanged += textboxFoodID_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(5, 29);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(67, 37);
            label1.TabIndex = 0;
            label1.Text = "ID :";
            // 
            // panel3
            // 
            panel3.Controls.Add(dataGridViewFood);
            panel3.Location = new Point(5, 166);
            panel3.Margin = new Padding(5);
            panel3.Name = "panel3";
            panel3.Size = new Size(863, 725);
            panel3.TabIndex = 0;
            // 
            // dataGridViewFood
            // 
            dataGridViewFood.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewFood.Location = new Point(8, 5);
            dataGridViewFood.Margin = new Padding(5);
            dataGridViewFood.Name = "dataGridViewFood";
            dataGridViewFood.RowHeadersWidth = 51;
            dataGridViewFood.Size = new Size(850, 720);
            dataGridViewFood.TabIndex = 0;
            dataGridViewFood.CellContentClick += dataGridViewFood_CellContentClick;
            // 
            // tabPageBill
            // 
            tabPageBill.Controls.Add(panel2);
            tabPageBill.Controls.Add(panel1);
            tabPageBill.Location = new Point(8, 46);
            tabPageBill.Margin = new Padding(5);
            tabPageBill.Name = "tabPageBill";
            tabPageBill.Padding = new Padding(5);
            tabPageBill.Size = new Size(1486, 895);
            tabPageBill.TabIndex = 0;
            tabPageBill.Text = "Doanh Thu";
            tabPageBill.UseVisualStyleBackColor = true;
            tabPageBill.Click += tabPageBill_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(buttonViewBill);
            panel2.Controls.Add(dateTimePickerToDate);
            panel2.Controls.Add(dateTimePickerFromDate);
            panel2.Location = new Point(5, 5);
            panel2.Margin = new Padding(5);
            panel2.Name = "panel2";
            panel2.Size = new Size(1469, 61);
            panel2.TabIndex = 1;
            // 
            // buttonViewBill
            // 
            buttonViewBill.Location = new Point(656, 5);
            buttonViewBill.Margin = new Padding(5);
            buttonViewBill.Name = "buttonViewBill";
            buttonViewBill.Size = new Size(190, 43);
            buttonViewBill.TabIndex = 2;
            buttonViewBill.Text = "Thống kê";
            buttonViewBill.UseVisualStyleBackColor = true;
            buttonViewBill.Click += buttonViewBill_Click;
            // 
            // dateTimePickerToDate
            // 
            dateTimePickerToDate.Location = new Point(1058, 5);
            dateTimePickerToDate.Margin = new Padding(5);
            dateTimePickerToDate.Name = "dateTimePickerToDate";
            dateTimePickerToDate.Size = new Size(404, 39);
            dateTimePickerToDate.TabIndex = 1;
            // 
            // dateTimePickerFromDate
            // 
            dateTimePickerFromDate.Location = new Point(8, 5);
            dateTimePickerFromDate.Margin = new Padding(5);
            dateTimePickerFromDate.Name = "dateTimePickerFromDate";
            dateTimePickerFromDate.Size = new Size(404, 39);
            dateTimePickerFromDate.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Controls.Add(textBoxPageBill);
            panel1.Controls.Add(buttonNextBillPage);
            panel1.Controls.Add(buttonLastBillPage);
            panel1.Controls.Add(buttonPreviousBillPage);
            panel1.Controls.Add(buttonFirst);
            panel1.Controls.Add(dataGridViewBill);
            panel1.Location = new Point(5, 75);
            panel1.Margin = new Padding(5);
            panel1.Name = "panel1";
            panel1.Size = new Size(1474, 811);
            panel1.TabIndex = 0;
            // 
            // textBoxPageBill
            // 
            textBoxPageBill.Location = new Point(656, 758);
            textBoxPageBill.Margin = new Padding(5);
            textBoxPageBill.Name = "textBoxPageBill";
            textBoxPageBill.ReadOnly = true;
            textBoxPageBill.Size = new Size(188, 39);
            textBoxPageBill.TabIndex = 5;
            textBoxPageBill.Text = "1";
            textBoxPageBill.TextAlign = HorizontalAlignment.Center;
            textBoxPageBill.TextChanged += textBoxPageBill_TextChanged;
            // 
            // buttonNextBillPage
            // 
            buttonNextBillPage.Location = new Point(1097, 758);
            buttonNextBillPage.Margin = new Padding(5);
            buttonNextBillPage.Name = "buttonNextBillPage";
            buttonNextBillPage.Size = new Size(179, 46);
            buttonNextBillPage.TabIndex = 4;
            buttonNextBillPage.Text = "Next";
            buttonNextBillPage.UseVisualStyleBackColor = true;
            buttonNextBillPage.Click += buttonNextBillPage_Click;
            // 
            // buttonLastBillPage
            // 
            buttonLastBillPage.Location = new Point(1285, 758);
            buttonLastBillPage.Margin = new Padding(5);
            buttonLastBillPage.Name = "buttonLastBillPage";
            buttonLastBillPage.Size = new Size(179, 46);
            buttonLastBillPage.TabIndex = 3;
            buttonLastBillPage.Text = "Last";
            buttonLastBillPage.UseVisualStyleBackColor = true;
            buttonLastBillPage.Click += buttonLastBillPage_Click;
            // 
            // buttonPreviousBillPage
            // 
            buttonPreviousBillPage.Location = new Point(193, 758);
            buttonPreviousBillPage.Margin = new Padding(5);
            buttonPreviousBillPage.Name = "buttonPreviousBillPage";
            buttonPreviousBillPage.Size = new Size(179, 46);
            buttonPreviousBillPage.TabIndex = 2;
            buttonPreviousBillPage.Text = "Previous";
            buttonPreviousBillPage.UseVisualStyleBackColor = true;
            buttonPreviousBillPage.Click += buttonPreviousBillPage_Click;
            // 
            // buttonFirst
            // 
            buttonFirst.Location = new Point(5, 758);
            buttonFirst.Margin = new Padding(5);
            buttonFirst.Name = "buttonFirst";
            buttonFirst.Size = new Size(179, 46);
            buttonFirst.TabIndex = 1;
            buttonFirst.Text = "First";
            buttonFirst.UseVisualStyleBackColor = true;
            buttonFirst.Click += buttonFirst_Click;
            // 
            // dataGridViewBill
            // 
            dataGridViewBill.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewBill.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewBill.Location = new Point(8, 10);
            dataGridViewBill.Margin = new Padding(5);
            dataGridViewBill.Name = "dataGridViewBill";
            dataGridViewBill.RowHeadersWidth = 51;
            dataGridViewBill.Size = new Size(1461, 739);
            dataGridViewBill.TabIndex = 0;
            dataGridViewBill.CellContentClick += dataGridViewBill_CellContentClick;
            // 
            // tabControlAdmin
            // 
            tabControlAdmin.Controls.Add(tabPageBill);
            tabControlAdmin.Controls.Add(tabPageFood);
            tabControlAdmin.Controls.Add(tabPageTable);
            tabControlAdmin.Controls.Add(tabPageCategory);
            tabControlAdmin.Controls.Add(tabPage1);
            tabControlAdmin.Location = new Point(0, 19);
            tabControlAdmin.Margin = new Padding(5);
            tabControlAdmin.Name = "tabControlAdmin";
            tabControlAdmin.SelectedIndex = 0;
            tabControlAdmin.Size = new Size(1502, 949);
            tabControlAdmin.TabIndex = 0;
            tabControlAdmin.SelectedIndexChanged += tabControl1_SelectedIndexChanged;
            // 
            // fAdmin
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1521, 987);
            Controls.Add(tabControlAdmin);
            Margin = new Padding(5);
            Name = "fAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin";
            Load += fAdmin_Load;
            tabPageCategory.ResumeLayout(false);
            panel13.ResumeLayout(false);
            panel16.ResumeLayout(false);
            panel22.ResumeLayout(false);
            panel22.PerformLayout();
            panel30.ResumeLayout(false);
            panel30.PerformLayout();
            panel31.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewCategory).EndInit();
            tabPageTable.ResumeLayout(false);
            panel11.ResumeLayout(false);
            panel14.ResumeLayout(false);
            panel21.ResumeLayout(false);
            panel21.PerformLayout();
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            panel19.ResumeLayout(false);
            panel19.PerformLayout();
            panel20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewTable).EndInit();
            tabPageFood.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel5.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownFoodPrice).EndInit();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewFood).EndInit();
            tabPageBill.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBill).EndInit();
            tabControlAdmin.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private NumericUpDown numericUpDown1;
        private TabPage tabPage1;
        private TabPage tabPageCategory;
        private Panel panel13;
        private Button buttonShowCategory;
        private Button buttonEditCategory;
        private Button buttonDeleteCategory;
        private Button buttonAddCategory;
        private Panel panel16;
        private Panel panel22;
        private TextBox textBoxNameCategory;
        private Label label14;
        private Panel panel30;
        private TextBox textBoxCategoryID;
        private Label label15;
        private Panel panel31;
        private DataGridView dataGridViewCategory;
        private TabPage tabPageTable;
        private Panel panel11;
        private Button buttonShowTable;
        private Button buttonEditTable;
        private Button buttonDeleteTable;
        private Button buttonAddTable;
        private Panel panel14;
        private Panel panel21;
        private ComboBox comboBoxTableStatus;
        private Label label9;
        private Panel panel15;
        private TextBox textBoxTableName;
        private Label label5;
        private Panel panel19;
        private TextBox textBoxTableID;
        private Label label6;
        private Panel panel20;
        private DataGridView dataGridViewTable;
        private TabPage tabPageFood;
        private Panel panel6;
        private TextBox textBoxSearchFoodName;
        private Button buttonSearchFood;
        private Panel panel5;
        private Button buttonShowFood;
        private Button buttonEditFood;
        private Button buttonDeleteFood;
        private Button buttonAddFood;
        private Panel panel4;
        private Panel panel10;
        private NumericUpDown numericUpDownFoodPrice;
        private Label label4;
        private Panel panel9;
        private ComboBox comboBoxFoodCategory;
        private Label label3;
        private Panel panel8;
        private TextBox textBoxFoodName;
        private Label label2;
        private Panel panel7;
        private TextBox textboxFoodID;
        private Label label1;
        private Panel panel3;
        private DataGridView dataGridViewFood;
        private TabPage tabPageBill;
        private Panel panel2;
        private Button buttonViewBill;
        private DateTimePicker dateTimePickerToDate;
        private DateTimePicker dateTimePickerFromDate;
        private Panel panel1;
        private TextBox textBoxPageBill;
        private Button buttonNextBillPage;
        private Button buttonLastBillPage;
        private Button buttonPreviousBillPage;
        private Button buttonFirst;
        private DataGridView dataGridViewBill;
        private TabControl tabControlAdmin;
    }
}