﻿namespace QuanLyQuanCafe
{
    partial class fAccountProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            textBoxUsername = new TextBox();
            label1 = new Label();
            panel1 = new Panel();
            textBoxDisplayName = new TextBox();
            label2 = new Label();
            panel3 = new Panel();
            textBoxPassword = new TextBox();
            label3 = new Label();
            panel4 = new Panel();
            textBoxNewPass = new TextBox();
            label4 = new Label();
            panel5 = new Panel();
            textBoxReturnEnterPass = new TextBox();
            label5 = new Label();
            buttonUpdate = new Button();
            buttonExit = new Button();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.Controls.Add(textBoxUsername);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(20, 19);
            panel2.Margin = new Padding(5, 5, 5, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(812, 98);
            panel2.TabIndex = 1;
            // 
            // textBoxUsername
            // 
            textBoxUsername.Location = new Point(283, 29);
            textBoxUsername.Margin = new Padding(5, 5, 5, 5);
            textBoxUsername.Name = "textBoxUsername";
            textBoxUsername.ReadOnly = true;
            textBoxUsername.Size = new Size(522, 39);
            textBoxUsername.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(5, 29);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(262, 37);
            label1.TabIndex = 0;
            label1.Text = "Tên đăng nhập :";
            // 
            // panel1
            // 
            panel1.Controls.Add(textBoxDisplayName);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(20, 126);
            panel1.Margin = new Padding(5, 5, 5, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(812, 98);
            panel1.TabIndex = 2;
            // 
            // textBoxDisplayName
            // 
            textBoxDisplayName.Location = new Point(283, 29);
            textBoxDisplayName.Margin = new Padding(5, 5, 5, 5);
            textBoxDisplayName.Name = "textBoxDisplayName";
            textBoxDisplayName.Size = new Size(522, 39);
            textBoxDisplayName.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(5, 29);
            label2.Margin = new Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new Size(217, 37);
            label2.TabIndex = 0;
            label2.Text = "Tên hiển thị :";
            // 
            // panel3
            // 
            panel3.Controls.Add(textBoxPassword);
            panel3.Controls.Add(label3);
            panel3.Location = new Point(20, 234);
            panel3.Margin = new Padding(5, 5, 5, 5);
            panel3.Name = "panel3";
            panel3.Size = new Size(812, 98);
            panel3.TabIndex = 3;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(283, 29);
            textBoxPassword.Margin = new Padding(5, 5, 5, 5);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(522, 39);
            textBoxPassword.TabIndex = 1;
            textBoxPassword.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(5, 29);
            label3.Margin = new Padding(5, 0, 5, 0);
            label3.Name = "label3";
            label3.Size = new Size(175, 37);
            label3.TabIndex = 0;
            label3.Text = "Mật khẩu :";
            // 
            // panel4
            // 
            panel4.Controls.Add(textBoxNewPass);
            panel4.Controls.Add(label4);
            panel4.Location = new Point(20, 341);
            panel4.Margin = new Padding(5, 5, 5, 5);
            panel4.Name = "panel4";
            panel4.Size = new Size(812, 98);
            panel4.TabIndex = 4;
            // 
            // textBoxNewPass
            // 
            textBoxNewPass.Location = new Point(283, 29);
            textBoxNewPass.Margin = new Padding(5, 5, 5, 5);
            textBoxNewPass.Name = "textBoxNewPass";
            textBoxNewPass.Size = new Size(522, 39);
            textBoxNewPass.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(5, 29);
            label4.Margin = new Padding(5, 0, 5, 0);
            label4.Name = "label4";
            label4.Size = new Size(245, 37);
            label4.TabIndex = 0;
            label4.Text = "Mật khẩu mới :";
            // 
            // panel5
            // 
            panel5.Controls.Add(textBoxReturnEnterPass);
            panel5.Controls.Add(label5);
            panel5.Location = new Point(18, 448);
            panel5.Margin = new Padding(5, 5, 5, 5);
            panel5.Name = "panel5";
            panel5.Size = new Size(812, 98);
            panel5.TabIndex = 5;
            // 
            // textBoxReturnEnterPass
            // 
            textBoxReturnEnterPass.Location = new Point(283, 29);
            textBoxReturnEnterPass.Margin = new Padding(5, 5, 5, 5);
            textBoxReturnEnterPass.Name = "textBoxReturnEnterPass";
            textBoxReturnEnterPass.Size = new Size(522, 39);
            textBoxReturnEnterPass.TabIndex = 1;
            textBoxReturnEnterPass.TextChanged += textBoxReturnEnterPass_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(5, 29);
            label5.Margin = new Padding(5, 0, 5, 0);
            label5.Name = "label5";
            label5.Size = new Size(161, 37);
            label5.TabIndex = 0;
            label5.Text = "Nhập lại :";
            // 
            // buttonUpdate
            // 
            buttonUpdate.Location = new Point(491, 552);
            buttonUpdate.Margin = new Padding(5, 5, 5, 5);
            buttonUpdate.Name = "buttonUpdate";
            buttonUpdate.Size = new Size(141, 53);
            buttonUpdate.TabIndex = 6;
            buttonUpdate.Text = "Cập nhật";
            buttonUpdate.UseVisualStyleBackColor = true;
            buttonUpdate.Click += buttonUpdate_Click;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(642, 552);
            buttonExit.Margin = new Padding(5, 5, 5, 5);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(141, 53);
            buttonExit.TabIndex = 7;
            buttonExit.Text = "Thoát";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // fAccountProfile
            // 
            AcceptButton = buttonUpdate;
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(855, 624);
            Controls.Add(buttonExit);
            Controls.Add(buttonUpdate);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Margin = new Padding(5, 5, 5, 5);
            Name = "fAccountProfile";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Thông tin cá nhân";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private TextBox textBoxUsername;
        private Label label1;
        private Panel panel1;
        private TextBox textBoxDisplayName;
        private Label label2;
        private Panel panel3;
        private TextBox textBoxPassword;
        private Label label3;
        private Panel panel4;
        private TextBox textBoxNewPass;
        private Label label4;
        private Panel panel5;
        private TextBox textBoxReturnEnterPass;
        private Label label5;
        private Button buttonUpdate;
        private Button buttonExit;
    }
}