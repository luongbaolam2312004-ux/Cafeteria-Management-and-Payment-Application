﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QuanLyQuanCafe.DAO;
using QuanLyQuanCafe.DTO;
using System.Diagnostics;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace QuanLyQuanCafe
{
    public partial class fAdmin : Form
    {
        BindingSource foodList = new BindingSource();
        BindingSource tableList = new BindingSource();
        BindingSource categoryList = new BindingSource();

        public Account loginAccount;

        public fAdmin()
        {
            InitializeComponent();
            LoadData();
            dataGridViewCategory.SelectionChanged += dataGridViewCategory_SelectionChanged;
            dataGridViewFood.SelectionChanged += dataGridViewFood_SelectionChanged;
            dataGridViewTable.SelectionChanged += dataGridViewTable_SelectionChanged;
        }

        #region methods

        List<Food> SearchFoodByName(string name)
        {
            List<Food> listFood = FoodDAO.Instance.SearchFoodByName(name);
            return listFood;
        }

        void LoadData()
        {
            LoadTable();
            dataGridViewFood.DataSource = foodList;
            dataGridViewTable.DataSource = tableList;
            dataGridViewCategory.DataSource = categoryList;
            LoadDateTimePickerBill();
            LoadListBillByDate(dateTimePickerFromDate.Value, dateTimePickerToDate.Value);
            LoadListFood();
            LoadCategoryIntoComboBox(comboBoxFoodCategory);
            AddFoodBinding();
            AddTableBinding();
            LoadCategory();
            AddCategoryBinding();
            LoadCategoryList();
        }

        void LoadCategory()
        {
            categoryList.DataSource = CategoryDAO.Instance.GetListCategory();
            dataGridViewCategory.DataSource = categoryList;
        }

        void AddCategoryBinding()
        {
            textBoxCategoryID.DataBindings.Clear();
            textBoxNameCategory.DataBindings.Clear();

            textBoxCategoryID.DataBindings.Add(new Binding("Text", dataGridViewCategory.DataSource, "ID", true, DataSourceUpdateMode.OnPropertyChanged));
            textBoxNameCategory.DataBindings.Add(new Binding("Text", dataGridViewCategory.DataSource, "Name", true, DataSourceUpdateMode.OnPropertyChanged));
        }



        void AddTableBinding()
        {
            textBoxTableID.DataBindings.Clear();
            textBoxTableName.DataBindings.Clear();
            comboBoxTableStatus.DataBindings.Clear();

            textBoxTableID.DataBindings.Add(new Binding("Text", dataGridViewTable.DataSource, "ID", true, DataSourceUpdateMode.OnPropertyChanged));
            textBoxTableName.DataBindings.Add(new Binding("Text", dataGridViewTable.DataSource, "Name", true, DataSourceUpdateMode.OnPropertyChanged));
            comboBoxTableStatus.DataBindings.Add(new Binding("Text", dataGridViewTable.DataSource, "Status", true, DataSourceUpdateMode.OnPropertyChanged));
        }

        void AddFoodBinding()
        {
            textBoxFoodName.DataBindings.Clear();
            textboxFoodID.DataBindings.Clear();
            numericUpDownFoodPrice.DataBindings.Clear();

            textBoxFoodName.DataBindings.Add(new Binding("Text", dataGridViewFood.DataSource, "Name", true, DataSourceUpdateMode.OnPropertyChanged));
            textboxFoodID.DataBindings.Add(new Binding("Text", dataGridViewFood.DataSource, "ID", true, DataSourceUpdateMode.OnPropertyChanged));
            numericUpDownFoodPrice.DataBindings.Add(new Binding("Value", dataGridViewFood.DataSource, "Price", true, DataSourceUpdateMode.OnPropertyChanged));
        }

        void LoadCategoryIntoComboBox(ComboBox cb)
        {
            cb.DataSource = null;
            cb.DataSource = CategoryDAO.Instance.GetListCategory();
            cb.DisplayMember = "Name";
        }

        void LoadTable()
        {
            tableList.DataSource = TableDAO.Instance.LoadTableList();
            dataGridViewTable.DataSource = tableList;

            dataGridViewTable.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            dataGridViewTable.Columns["Status"].Width = 160;
            dataGridViewTable.Columns["Name"].Width = 150;
            dataGridViewTable.Columns["ID"].Width = 98;

            dataGridViewTable.Columns["Status"].HeaderText = "Trạng thái";
            dataGridViewTable.Columns["Name"].HeaderText = "Tên bàn";
            dataGridViewTable.Columns["ID"].HeaderText = "Mã bàn";

            dataGridViewTable.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            dataGridViewTable.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewTable.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        }



        void LoadDateTimePickerBill()
        {
            DateTime today = DateTime.Now;
            dateTimePickerFromDate.Value = new DateTime(today.Year, today.Month, 1);
            dateTimePickerToDate.Value = dateTimePickerFromDate.Value.AddMonths(1).AddDays(-1);
        }

        void LoadListBillByDate(DateTime checkIn, DateTime checkOut)
        {
            dataGridViewBill.DataSource = BillDAO.Instance.GetBillListByDate(checkIn, checkOut);
            dataGridViewBill.Columns["Tổng tiền"].HeaderText = "Tổng tiền (x1000)";
        }

        void LoadListFood()
        {
            foodList.DataSource = FoodDAO.Instance.GetListFood();
            dataGridViewFood.DataSource = foodList;

            dataGridViewFood.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            dataGridViewFood.Columns["Name"].Width = 250;
            dataGridViewFood.Columns["Price"].Width = 107;
            dataGridViewFood.Columns["ID"].Width = 91;

            dataGridViewFood.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridViewFood.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridViewFood.DefaultCellStyle.Font = new Font("Segoe UI", 10);

            dataGridViewFood.Columns["Name"].HeaderText = "Tên món";
            dataGridViewFood.Columns["Price"].HeaderText = "Giá";
            dataGridViewFood.Columns["ID"].HeaderText = "Mã món";

            dataGridViewFood.Columns["Name"].DisplayIndex = 0;
            dataGridViewFood.Columns["Price"].DisplayIndex = 1;
            dataGridViewFood.Columns["ID"].DisplayIndex = 2;

            dataGridViewFood.Columns["CategoryID"].Visible = false;
        }





        #endregion

        #region events

        private void dataGridViewCategory_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewCategory.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridViewCategory.SelectedRows[0].Index;
                categoryList.Position = selectedIndex;
            }
        }

        private void dataGridViewFood_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewFood.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridViewFood.SelectedRows[0].Index;
                foodList.Position = selectedIndex;
            }
        }

        private void dataGridViewTable_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewTable.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridViewTable.SelectedRows[0].Index;
                tableList.Position = selectedIndex;
            }
        }

        private void textboxFoodID_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewFood.SelectedCells.Count > 0)
                {
                    int id = (int)dataGridViewFood.SelectedCells[0].OwningRow.Cells["CategoryID"].Value;
                    Category category = CategoryDAO.Instance.GetCatrgoryByID(id);
                    comboBoxFoodCategory.SelectedItem = category;
                    int index = -1;
                    int i = 0;
                    foreach (Category item in comboBoxFoodCategory.Items)
                    {
                        if (item.ID == category.ID)
                        {
                            index = i;
                            break;
                        }
                        i++;
                    }
                    comboBoxFoodCategory.SelectedIndex = index;
                }
            }
            catch { }
        }

        private void buttonAddFood_Click(object sender, EventArgs e)
        {
            string name = textBoxFoodName.Text;
            int categoryID = (comboBoxFoodCategory.SelectedItem as Category).ID;
            float price = (float)numericUpDownFoodPrice.Value;

            if (FoodDAO.Instance.InsertFood(name, categoryID, price))
            {
                MessageBox.Show("Thêm món thành công");
                LoadListFood();
                if (insertFood != null)
                    insertFood(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Có lỗi khi thêm thức ăn");
            }
        }

        private void buttonEditFood_Click(object sender, EventArgs e)
        {
            string name = textBoxFoodName.Text;
            int categoryID = (comboBoxFoodCategory.SelectedItem as Category).ID;
            float price = (float)numericUpDownFoodPrice.Value;
            int id = Convert.ToInt32(textboxFoodID.Text);

            if (FoodDAO.Instance.UpdateFood(id, name, categoryID, price))
            {
                MessageBox.Show("Sửa món thành công");
                LoadListFood();
                if (updateFood != null)
                    updateFood(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Có lỗi khi sửa thức ăn");
            }
        }

        private void buttonDeleteFood_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textboxFoodID.Text);

            if (FoodDAO.Instance.DeleteFood(id))
            {
                MessageBox.Show("Xóa món thành công");
                LoadListFood();
                if (deleteFood != null)
                    deleteFood(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Có lỗi khi xóa thức ăn");
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void tabPageBill_Click(object sender, EventArgs e)
        {
        }

        private void buttonShowTable_Click(object sender, EventArgs e)
        {
        }

        private void fAdmin_Load(object sender, EventArgs e)
        {
        }


        private void buttonViewBill_Click(object sender, EventArgs e)
        {
            LoadListBillByDate(dateTimePickerFromDate.Value, dateTimePickerToDate.Value);
        }

        private void buttonSearchFood_Click(object sender, EventArgs e)
        {
            foodList.DataSource = SearchFoodByName(textBoxSearchFoodName.Text);
        }

        private void dataGridViewFood_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }



        private void buttonFirst_Click(object sender, EventArgs e)
        {
            textBoxPageBill.Text = "1";
        }

        private void buttonLastBillPage_Click(object sender, EventArgs e)
        {
            int sumRecord = BillDAO.Instance.GetNumBillByDate(dateTimePickerFromDate.Value, dateTimePickerToDate.Value);
            int lastPage = sumRecord / 10;
            if (sumRecord % 10 != 0)
                lastPage++;
            textBoxPageBill.Text = lastPage.ToString();
        }

        private void textBoxPageBill_TextChanged(object sender, EventArgs e)
        {
            dataGridViewBill.DataSource = BillDAO.Instance.GetBillListByDateAndPage(dateTimePickerFromDate.Value, dateTimePickerToDate.Value, Convert.ToInt32(textBoxPageBill.Text));
        }

        private void buttonPreviousBillPage_Click(object sender, EventArgs e)
        {
            int page = Convert.ToInt32(textBoxPageBill.Text);
            if (page > 1)
                page--;
            textBoxPageBill.Text = page.ToString();
        }

        private void buttonNextBillPage_Click(object sender, EventArgs e)
        {
            int page = Convert.ToInt32(textBoxPageBill.Text);
            int sumRecord = BillDAO.Instance.GetNumBillByDate(dateTimePickerFromDate.Value, dateTimePickerToDate.Value);
            if (page < sumRecord)
                page++;
            textBoxPageBill.Text = page.ToString();
        }

        private void buttonEditTable_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBoxTableID.Text);
            string name = textBoxTableName.Text;
            string status = comboBoxTableStatus.Text;

            if (TableDAO.Instance.UpdateTable(id, name, status))
            {
                MessageBox.Show("Cập nhật bàn thành công");
                LoadTable();
                if (updateTable != null)
                    updateTable(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Cập nhật bàn thất bại");
            }
        }

        private void buttonDeleteTable_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBoxTableID.Text);

            if (TableDAO.Instance.DeleteTable(id))
            {
                MessageBox.Show("Xóa bàn thành công");
                LoadTable();
                if (deleteTable != null)
                    deleteTable(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Xóa bàn thất bại");
            }
        }

        private void buttonAddTable_Click(object sender, EventArgs e)
        {
            string name = textBoxTableName.Text;
            string status = comboBoxTableStatus.Text;

            if (TableDAO.Instance.InsertTable(name, status))
            {
                MessageBox.Show("Thêm bàn thành công");
                LoadTable();
                if (insertTable != null)
                    insertTable(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Thêm bàn thất bại");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }


        void LoadCategoryList()
        {
            dataGridViewCategory.DataSource = CategoryDAO.Instance.GetListCategory();
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            string name = textBoxNameCategory.Text;

            if (CategoryDAO.Instance.InsertCategory(name))
            {
                MessageBox.Show("Thêm danh mục thành công!");
                LoadData();
                if (insertCategory != null)
                    insertCategory(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Có lỗi khi thêm danh mục!");
            }
        }

        private void buttonDeleteCategory_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxCategoryID.Text, out int id))
            {
                if (CategoryDAO.Instance.DeleteCategory(id))
                {
                    MessageBox.Show("Xóa danh mục thành công!");
                    LoadData();
                    if (deleteCategory != null)
                        deleteCategory(this, new EventArgs());
                }
                else
                {
                    MessageBox.Show("Có lỗi khi xóa danh mục!");
                }
            }
            else
            {
                MessageBox.Show("ID không hợp lệ!");
            }
        }

        private void buttonEditCategory_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxCategoryID.Text, out int id))
            {
                string name = textBoxNameCategory.Text;
                if (CategoryDAO.Instance.UpdateCategory(id, name))
                {
                    MessageBox.Show("Cập nhật danh mục thành công!");
                    LoadData();
                    if (updateCategory != null)
                        updateCategory(this, new EventArgs());
                }
                else
                {
                    MessageBox.Show("Có lỗi khi cập nhật danh mục!");
                }
            }
            else
            {
                MessageBox.Show("ID không hợp lệ!");
            }
        }



        private void dataGridViewBill_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        // Fix for CS0118: 'frmBestSellingFoods' is a type but is used like a variable  
        // The issue occurs because 'frmBestSellingFoods' is being used as a variable, but it is defined as a class.  
        // To fix this, declare a variable of type 'frmBestSellingFoods' and use it appropriately.

        private frmBestSellingFoods frmBestSellingFoodsInstance; // Declare a variable of type frmBestSellingFoods

        private void button1_Click(object sender, EventArgs e)
        {
            frmBestSellingFoodsInstance = new frmBestSellingFoods(); // Instantiate the variable
            frmBestSellingFoodsInstance.Show(); // Show the form
        }

        private void dateTimePickerToDate_ValueChanged(object sender, EventArgs e)
        {

        }


        private void dataGridViewTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel28_Paint(object sender, PaintEventArgs e)
        {

        }



        private void tabPageCategory_Click(object sender, EventArgs e)
        {

        }

        

        private event EventHandler insertFood;
        public event EventHandler InsertFood
        {
            add { insertFood += value; }
            remove { insertFood -= value; }
        }

        private event EventHandler deleteFood;
        public event EventHandler DeleteFood
        {
            add { deleteFood += value; }
            remove { deleteFood -= value; }
        }

        private event EventHandler updateFood;
        public event EventHandler UpdateFood
        {
            add { updateFood += value; }
            remove { updateFood -= value; }
        }

        private event EventHandler insertTable;
        public event EventHandler InsertTable
        {
            add { insertTable += value; }
            remove { insertTable -= value; }
        }

        private event EventHandler deleteTable;
        public event EventHandler DeleteTable
        {
            add { deleteTable += value; }
            remove { deleteTable -= value; }
        }

        private event EventHandler updateTable;
        public event EventHandler UpdateTable
        {
            add { updateTable += value; }
            remove { updateTable -= value; }
        }

        private event EventHandler insertCategory;
        public event EventHandler InsertCategory
        {
            add { insertCategory += value; }
            remove { insertCategory -= value; }
        }

        private event EventHandler deleteCategory;
        public event EventHandler DeleteCategory
        {
            add { deleteCategory += value; }
            remove { deleteCategory -= value; }
        }

        private event EventHandler updateCategory;
        public event EventHandler UpdateCategory
        {
            add { updateCategory += value; }
            remove { updateCategory -= value; }
        }

        #endregion
    }
}