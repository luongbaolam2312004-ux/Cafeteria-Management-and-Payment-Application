﻿using System;
using System.Windows.Forms;
using QuanLyQuanCafe.DAO;
using QuanLyQuanCafe.DTO;

namespace QuanLyQuanCafe
{
    public partial class frmBestSellingFoods : Form
    {
        public frmBestSellingFoods()
        {
            InitializeComponent();
            LoadDateTimePicker();
            LoadBestSellingFoods();
        }

        void LoadDateTimePicker()
        {
            DateTime today = DateTime.Now;
            dtpFromDate.Value = new DateTime(today.Year, today.Month, 1);
            dtpToDate.Value = dtpFromDate.Value.AddMonths(1).AddDays(-1);
        }

        void LoadBestSellingFoods()
        {
            DateTime fromDate = dtpFromDate.Value;
            DateTime toDate = dtpToDate.Value;
            int topN = (int)nmTopN.Value;

            dgvBestSellingFoods.DataSource = BestSellingFoodDAO.Instance.GetBestSellingFoods(fromDate, toDate, topN);

            // Định dạng cột
            dgvBestSellingFoods.Columns["FoodId"].Visible = false;
            dgvBestSellingFoods.Columns["FoodName"].HeaderText = "Tên món";
            dgvBestSellingFoods.Columns["CategoryName"].HeaderText = "Danh mục";
            dgvBestSellingFoods.Columns["TotalSold"].HeaderText = "Số lượng bán";
            dgvBestSellingFoods.Columns["Price"].HeaderText = "Đơn giá";
            dgvBestSellingFoods.Columns["TotalRevenue"].HeaderText = "Tổng doanh thu";

            // Định dạng hiển thị số
            dgvBestSellingFoods.Columns["Price"].DefaultCellStyle.Format = "N0";
            dgvBestSellingFoods.Columns["TotalRevenue"].DefaultCellStyle.Format = "N0";
            dgvBestSellingFoods.Columns["TotalSold"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvBestSellingFoods.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvBestSellingFoods.Columns["TotalRevenue"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            LoadBestSellingFoods();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}