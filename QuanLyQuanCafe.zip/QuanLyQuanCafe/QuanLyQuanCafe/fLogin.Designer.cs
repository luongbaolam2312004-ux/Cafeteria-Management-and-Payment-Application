﻿namespace QuanLyQuanCafe
{
    partial class fLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            buttonLogin = new Button();
            buttonExit = new Button();
            panel3 = new Panel();
            textBoxPassword = new TextBox();
            label2 = new Label();
            panel2 = new Panel();
            textBoxUsername = new TextBox();
            label1 = new Label();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(buttonLogin);
            panel1.Controls.Add(buttonExit);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(20, 19);
            panel1.Margin = new Padding(5, 5, 5, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(832, 274);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // buttonLogin
            // 
            buttonLogin.Location = new Point(502, 219);
            buttonLogin.Margin = new Padding(5, 5, 5, 5);
            buttonLogin.Name = "buttonLogin";
            buttonLogin.Size = new Size(153, 46);
            buttonLogin.TabIndex = 3;
            buttonLogin.Text = "Đăng nhập";
            buttonLogin.UseVisualStyleBackColor = true;
            buttonLogin.Click += buttonLogin_Click;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(665, 219);
            buttonExit.Margin = new Padding(5, 5, 5, 5);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(153, 46);
            buttonExit.TabIndex = 4;
            buttonExit.Text = "Thoát";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click_1;
            // 
            // panel3
            // 
            panel3.Controls.Add(textBoxPassword);
            panel3.Controls.Add(label2);
            panel3.Location = new Point(10, 112);
            panel3.Margin = new Padding(5, 5, 5, 5);
            panel3.Name = "panel3";
            panel3.Size = new Size(812, 98);
            panel3.TabIndex = 2;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(283, 29);
            textBoxPassword.Margin = new Padding(5, 5, 5, 5);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(522, 39);
            textBoxPassword.TabIndex = 2;
            textBoxPassword.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(5, 29);
            label2.Margin = new Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new Size(175, 37);
            label2.TabIndex = 0;
            label2.Text = "Mật khẩu :";
            // 
            // panel2
            // 
            panel2.Controls.Add(textBoxUsername);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(5, 5);
            panel2.Margin = new Padding(5, 5, 5, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(812, 98);
            panel2.TabIndex = 0;
            // 
            // textBoxUsername
            // 
            textBoxUsername.Location = new Point(283, 29);
            textBoxUsername.Margin = new Padding(5, 5, 5, 5);
            textBoxUsername.Name = "textBoxUsername";
            textBoxUsername.Size = new Size(522, 39);
            textBoxUsername.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(5, 29);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(262, 37);
            label1.TabIndex = 0;
            label1.Text = "Tên đăng nhập :";
            // 
            // fLogin
            // 
            AcceptButton = buttonLogin;
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonExit;
            ClientSize = new Size(871, 317);
            Controls.Add(panel1);
            Margin = new Padding(5, 5, 5, 5);
            Name = "fLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Đăng nhập :";
            FormClosing += fLogin_FormClosing;
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel3;
        private TextBox textBoxPassword;
        private Label label2;
        private Panel panel2;
        private TextBox textBoxUsername;
        private Label label1;
        private Button buttonExit;
        private Button buttonLogin;
    }
}
